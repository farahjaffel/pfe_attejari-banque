// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package dwh_attejaribank.j_load_dim_finanier_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: J_Load_Dim_Finanier Purpose: <br>
 * Description:  <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class J_Load_Dim_Finanier implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(host != null){
				
					this.setProperty("host", host.toString());
				
			}
			
			if(port != null){
				
					this.setProperty("port", port.toString());
				
			}
			
			if(schema != null){
				
					this.setProperty("schema", schema.toString());
				
			}
			
			if(database != null){
				
					this.setProperty("database", database.toString());
				
			}
			
			if(password != null){
				
					this.setProperty("password", password.toString());
				
			}
			
			if(params != null){
				
					this.setProperty("params", params.toString());
				
			}
			
			if(username != null){
				
					this.setProperty("username", username.toString());
				
			}
			
			if(schema_staging != null){
				
					this.setProperty("schema_staging", schema_staging.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String host;
public String getHost(){
	return this.host;
}
public BigDecimal port;
public BigDecimal getPort(){
	return this.port;
}
public String schema;
public String getSchema(){
	return this.schema;
}
public String database;
public String getDatabase(){
	return this.database;
}
public String password;
public String getPassword(){
	return this.password;
}
public String params;
public String getParams(){
	return this.params;
}
public String username;
public String getUsername(){
	return this.username;
}
public String schema_staging;
public String getSchema_staging(){
	return this.schema_staging;
}
	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "J_Load_Dim_Finanier";
	private final String projectName = "DWH_ATTEJARIBANK";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				J_Load_Dim_Finanier.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(J_Load_Dim_Finanier.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_row2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	






public static class dimStruct implements routines.system.IPersistableRow<dimStruct> {
    final static byte[] commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[0];
    static byte[] commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_financier_sk;

				public int getId_financier_sk () {
					return this.id_financier_sk;
				}
				
			    public String id_client;

				public String getId_client () {
					return this.id_client;
				}
				
			    public int id_type_convention_sk;

				public int getId_type_convention_sk () {
					return this.id_type_convention_sk;
				}
				
			    public String methode_paiement_fav;

				public String getMethode_paiement_fav () {
					return this.methode_paiement_fav;
				}
				
			    public Double frais_bancaires_mensuels;

				public Double getFrais_bancaires_mensuels () {
					return this.frais_bancaires_mensuels;
				}
				
			    public Double total_frais_cumules;

				public Double getTotal_frais_cumules () {
					return this.total_frais_cumules;
				}
				
			    public Double revenu_mensuel;

				public Double getRevenu_mensuel () {
					return this.revenu_mensuel;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_client == null) ? 0 : this.id_client.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final dimStruct other = (dimStruct) obj;
		
						if (this.id_client == null) {
							if (other.id_client != null)
								return false;
						
						} else if (!this.id_client.equals(other.id_client))
						
							return false;
					

		return true;
    }

	public void copyDataTo(dimStruct other) {

		other.id_financier_sk = this.id_financier_sk;
	            other.id_client = this.id_client;
	            other.id_type_convention_sk = this.id_type_convention_sk;
	            other.methode_paiement_fav = this.methode_paiement_fav;
	            other.frais_bancaires_mensuels = this.frais_bancaires_mensuels;
	            other.total_frais_cumules = this.total_frais_cumules;
	            other.revenu_mensuel = this.revenu_mensuel;
	            
	}

	public void copyKeysDataTo(dimStruct other) {

		other.id_client = this.id_client;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length) {
				if(length < 1024 && commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length == 0) {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[1024];
				} else {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length);
			strReturn = new String(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length) {
				if(length < 1024 && commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length == 0) {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[1024];
				} else {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length);
			strReturn = new String(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier) {

        	try {

        		int length = 0;
		
			        this.id_financier_sk = dis.readInt();
					
					this.id_client = readString(dis);
					
			        this.id_type_convention_sk = dis.readInt();
					
					this.methode_paiement_fav = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.frais_bancaires_mensuels = null;
           				} else {
           			    	this.frais_bancaires_mensuels = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_frais_cumules = null;
           				} else {
           			    	this.total_frais_cumules = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenu_mensuel = null;
           				} else {
           			    	this.revenu_mensuel = dis.readDouble();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier) {

        	try {

        		int length = 0;
		
			        this.id_financier_sk = dis.readInt();
					
					this.id_client = readString(dis);
					
			        this.id_type_convention_sk = dis.readInt();
					
					this.methode_paiement_fav = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.frais_bancaires_mensuels = null;
           				} else {
           			    	this.frais_bancaires_mensuels = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_frais_cumules = null;
           				} else {
           			    	this.total_frais_cumules = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenu_mensuel = null;
           				} else {
           			    	this.revenu_mensuel = dis.readDouble();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_financier_sk);
					
					// String
				
						writeString(this.id_client,dos);
					
					// int
				
		            	dos.writeInt(this.id_type_convention_sk);
					
					// String
				
						writeString(this.methode_paiement_fav,dos);
					
					// Double
				
						if(this.frais_bancaires_mensuels == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.frais_bancaires_mensuels);
		            	}
					
					// Double
				
						if(this.total_frais_cumules == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_frais_cumules);
		            	}
					
					// Double
				
						if(this.revenu_mensuel == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.revenu_mensuel);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id_financier_sk);
					
					// String
				
						writeString(this.id_client,dos);
					
					// int
				
		            	dos.writeInt(this.id_type_convention_sk);
					
					// String
				
						writeString(this.methode_paiement_fav,dos);
					
					// Double
				
						if(this.frais_bancaires_mensuels == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.frais_bancaires_mensuels);
		            	}
					
					// Double
				
						if(this.total_frais_cumules == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_frais_cumules);
		            	}
					
					// Double
				
						if(this.revenu_mensuel == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.revenu_mensuel);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_financier_sk="+String.valueOf(id_financier_sk));
		sb.append(",id_client="+id_client);
		sb.append(",id_type_convention_sk="+String.valueOf(id_type_convention_sk));
		sb.append(",methode_paiement_fav="+methode_paiement_fav);
		sb.append(",frais_bancaires_mensuels="+String.valueOf(frais_bancaires_mensuels));
		sb.append(",total_frais_cumules="+String.valueOf(total_frais_cumules));
		sb.append(",revenu_mensuel="+String.valueOf(revenu_mensuel));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(dimStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_client, other.id_client);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[0];
    static byte[] commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[0];

	
			    public String id_client;

				public String getId_client () {
					return this.id_client;
				}
				
			    public String sexe;

				public String getSexe () {
					return this.sexe;
				}
				
			    public java.util.Date date_naissance;

				public java.util.Date getDate_naissance () {
					return this.date_naissance;
				}
				
			    public Integer est_senior;

				public Integer getEst_senior () {
					return this.est_senior;
				}
				
			    public String situation_matrimoniale;

				public String getSituation_matrimoniale () {
					return this.situation_matrimoniale;
				}
				
			    public Long enfants_a_charge;

				public Long getEnfants_a_charge () {
					return this.enfants_a_charge;
				}
				
			    public String profession;

				public String getProfession () {
					return this.profession;
				}
				
			    public String ville_region;

				public String getVille_region () {
					return this.ville_region;
				}
				
			    public Integer anciennete_mois;

				public Integer getAnciennete_mois () {
					return this.anciennete_mois;
				}
				
			    public Integer service_sms_banking;

				public Integer getService_sms_banking () {
					return this.service_sms_banking;
				}
				
			    public String acces_banque_en_ligne;

				public String getAcces_banque_en_ligne () {
					return this.acces_banque_en_ligne;
				}
				
			    public Integer alerte_securite_active;

				public Integer getAlerte_securite_active () {
					return this.alerte_securite_active;
				}
				
			    public Integer assurance_moyen_paiement;

				public Integer getAssurance_moyen_paiement () {
					return this.assurance_moyen_paiement;
				}
				
			    public Integer conseiller_dedie;

				public Integer getConseiller_dedie () {
					return this.conseiller_dedie;
				}
				
			    public Integer programme_fidelite;

				public Integer getProgramme_fidelite () {
					return this.programme_fidelite;
				}
				
			    public String type_convention;

				public String getType_convention () {
					return this.type_convention;
				}
				
			    public Integer e_releve_active;

				public Integer getE_releve_active () {
					return this.e_releve_active;
				}
				
			    public String methode_paiement_fav;

				public String getMethode_paiement_fav () {
					return this.methode_paiement_fav;
				}
				
			    public Double frais_bancaires_mensuels;

				public Double getFrais_bancaires_mensuels () {
					return this.frais_bancaires_mensuels;
				}
				
			    public Double total_frais_cumules;

				public Double getTotal_frais_cumules () {
					return this.total_frais_cumules;
				}
				
			    public Double revenu_mensuel;

				public Double getRevenu_mensuel () {
					return this.revenu_mensuel;
				}
				
			    public Long nb_produits_actifs;

				public Long getNb_produits_actifs () {
					return this.nb_produits_actifs;
				}
				
			    public Double score_risque_interne;

				public Double getScore_risque_interne () {
					return this.score_risque_interne;
				}
				
			    public Long churn;

				public Long getChurn () {
					return this.churn;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length) {
				if(length < 1024 && commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length == 0) {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[1024];
				} else {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length);
			strReturn = new String(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length) {
				if(length < 1024 && commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length == 0) {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[1024];
				} else {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length);
			strReturn = new String(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier) {

        	try {

        		int length = 0;
		
					this.id_client = readString(dis);
					
					this.sexe = readString(dis);
					
					this.date_naissance = readDate(dis);
					
						this.est_senior = readInteger(dis);
					
					this.situation_matrimoniale = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.enfants_a_charge = null;
           				} else {
           			    	this.enfants_a_charge = dis.readLong();
           				}
					
					this.profession = readString(dis);
					
					this.ville_region = readString(dis);
					
						this.anciennete_mois = readInteger(dis);
					
						this.service_sms_banking = readInteger(dis);
					
					this.acces_banque_en_ligne = readString(dis);
					
						this.alerte_securite_active = readInteger(dis);
					
						this.assurance_moyen_paiement = readInteger(dis);
					
						this.conseiller_dedie = readInteger(dis);
					
						this.programme_fidelite = readInteger(dis);
					
					this.type_convention = readString(dis);
					
						this.e_releve_active = readInteger(dis);
					
					this.methode_paiement_fav = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.frais_bancaires_mensuels = null;
           				} else {
           			    	this.frais_bancaires_mensuels = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_frais_cumules = null;
           				} else {
           			    	this.total_frais_cumules = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenu_mensuel = null;
           				} else {
           			    	this.revenu_mensuel = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.nb_produits_actifs = null;
           				} else {
           			    	this.nb_produits_actifs = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.score_risque_interne = null;
           				} else {
           			    	this.score_risque_interne = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.churn = null;
           				} else {
           			    	this.churn = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier) {

        	try {

        		int length = 0;
		
					this.id_client = readString(dis);
					
					this.sexe = readString(dis);
					
					this.date_naissance = readDate(dis);
					
						this.est_senior = readInteger(dis);
					
					this.situation_matrimoniale = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.enfants_a_charge = null;
           				} else {
           			    	this.enfants_a_charge = dis.readLong();
           				}
					
					this.profession = readString(dis);
					
					this.ville_region = readString(dis);
					
						this.anciennete_mois = readInteger(dis);
					
						this.service_sms_banking = readInteger(dis);
					
					this.acces_banque_en_ligne = readString(dis);
					
						this.alerte_securite_active = readInteger(dis);
					
						this.assurance_moyen_paiement = readInteger(dis);
					
						this.conseiller_dedie = readInteger(dis);
					
						this.programme_fidelite = readInteger(dis);
					
					this.type_convention = readString(dis);
					
						this.e_releve_active = readInteger(dis);
					
					this.methode_paiement_fav = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.frais_bancaires_mensuels = null;
           				} else {
           			    	this.frais_bancaires_mensuels = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_frais_cumules = null;
           				} else {
           			    	this.total_frais_cumules = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenu_mensuel = null;
           				} else {
           			    	this.revenu_mensuel = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.nb_produits_actifs = null;
           				} else {
           			    	this.nb_produits_actifs = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.score_risque_interne = null;
           				} else {
           			    	this.score_risque_interne = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.churn = null;
           				} else {
           			    	this.churn = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.id_client,dos);
					
					// String
				
						writeString(this.sexe,dos);
					
					// java.util.Date
				
						writeDate(this.date_naissance,dos);
					
					// Integer
				
						writeInteger(this.est_senior,dos);
					
					// String
				
						writeString(this.situation_matrimoniale,dos);
					
					// Long
				
						if(this.enfants_a_charge == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.enfants_a_charge);
		            	}
					
					// String
				
						writeString(this.profession,dos);
					
					// String
				
						writeString(this.ville_region,dos);
					
					// Integer
				
						writeInteger(this.anciennete_mois,dos);
					
					// Integer
				
						writeInteger(this.service_sms_banking,dos);
					
					// String
				
						writeString(this.acces_banque_en_ligne,dos);
					
					// Integer
				
						writeInteger(this.alerte_securite_active,dos);
					
					// Integer
				
						writeInteger(this.assurance_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.conseiller_dedie,dos);
					
					// Integer
				
						writeInteger(this.programme_fidelite,dos);
					
					// String
				
						writeString(this.type_convention,dos);
					
					// Integer
				
						writeInteger(this.e_releve_active,dos);
					
					// String
				
						writeString(this.methode_paiement_fav,dos);
					
					// Double
				
						if(this.frais_bancaires_mensuels == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.frais_bancaires_mensuels);
		            	}
					
					// Double
				
						if(this.total_frais_cumules == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_frais_cumules);
		            	}
					
					// Double
				
						if(this.revenu_mensuel == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.revenu_mensuel);
		            	}
					
					// Long
				
						if(this.nb_produits_actifs == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.nb_produits_actifs);
		            	}
					
					// Double
				
						if(this.score_risque_interne == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.score_risque_interne);
		            	}
					
					// Long
				
						if(this.churn == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.churn);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.id_client,dos);
					
					// String
				
						writeString(this.sexe,dos);
					
					// java.util.Date
				
						writeDate(this.date_naissance,dos);
					
					// Integer
				
						writeInteger(this.est_senior,dos);
					
					// String
				
						writeString(this.situation_matrimoniale,dos);
					
					// Long
				
						if(this.enfants_a_charge == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.enfants_a_charge);
		            	}
					
					// String
				
						writeString(this.profession,dos);
					
					// String
				
						writeString(this.ville_region,dos);
					
					// Integer
				
						writeInteger(this.anciennete_mois,dos);
					
					// Integer
				
						writeInteger(this.service_sms_banking,dos);
					
					// String
				
						writeString(this.acces_banque_en_ligne,dos);
					
					// Integer
				
						writeInteger(this.alerte_securite_active,dos);
					
					// Integer
				
						writeInteger(this.assurance_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.conseiller_dedie,dos);
					
					// Integer
				
						writeInteger(this.programme_fidelite,dos);
					
					// String
				
						writeString(this.type_convention,dos);
					
					// Integer
				
						writeInteger(this.e_releve_active,dos);
					
					// String
				
						writeString(this.methode_paiement_fav,dos);
					
					// Double
				
						if(this.frais_bancaires_mensuels == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.frais_bancaires_mensuels);
		            	}
					
					// Double
				
						if(this.total_frais_cumules == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_frais_cumules);
		            	}
					
					// Double
				
						if(this.revenu_mensuel == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.revenu_mensuel);
		            	}
					
					// Long
				
						if(this.nb_produits_actifs == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.nb_produits_actifs);
		            	}
					
					// Double
				
						if(this.score_risque_interne == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.score_risque_interne);
		            	}
					
					// Long
				
						if(this.churn == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.churn);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_client="+id_client);
		sb.append(",sexe="+sexe);
		sb.append(",date_naissance="+String.valueOf(date_naissance));
		sb.append(",est_senior="+String.valueOf(est_senior));
		sb.append(",situation_matrimoniale="+situation_matrimoniale);
		sb.append(",enfants_a_charge="+String.valueOf(enfants_a_charge));
		sb.append(",profession="+profession);
		sb.append(",ville_region="+ville_region);
		sb.append(",anciennete_mois="+String.valueOf(anciennete_mois));
		sb.append(",service_sms_banking="+String.valueOf(service_sms_banking));
		sb.append(",acces_banque_en_ligne="+acces_banque_en_ligne);
		sb.append(",alerte_securite_active="+String.valueOf(alerte_securite_active));
		sb.append(",assurance_moyen_paiement="+String.valueOf(assurance_moyen_paiement));
		sb.append(",conseiller_dedie="+String.valueOf(conseiller_dedie));
		sb.append(",programme_fidelite="+String.valueOf(programme_fidelite));
		sb.append(",type_convention="+type_convention);
		sb.append(",e_releve_active="+String.valueOf(e_releve_active));
		sb.append(",methode_paiement_fav="+methode_paiement_fav);
		sb.append(",frais_bancaires_mensuels="+String.valueOf(frais_bancaires_mensuels));
		sb.append(",total_frais_cumules="+String.valueOf(total_frais_cumules));
		sb.append(",revenu_mensuel="+String.valueOf(revenu_mensuel));
		sb.append(",nb_produits_actifs="+String.valueOf(nb_produits_actifs));
		sb.append(",score_risque_interne="+String.valueOf(score_risque_interne));
		sb.append(",churn="+String.valueOf(churn));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_tDBInput_1Struct implements routines.system.IPersistableRow<after_tDBInput_1Struct> {
    final static byte[] commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[0];
    static byte[] commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String id_client;

				public String getId_client () {
					return this.id_client;
				}
				
			    public String sexe;

				public String getSexe () {
					return this.sexe;
				}
				
			    public java.util.Date date_naissance;

				public java.util.Date getDate_naissance () {
					return this.date_naissance;
				}
				
			    public Integer est_senior;

				public Integer getEst_senior () {
					return this.est_senior;
				}
				
			    public String situation_matrimoniale;

				public String getSituation_matrimoniale () {
					return this.situation_matrimoniale;
				}
				
			    public Long enfants_a_charge;

				public Long getEnfants_a_charge () {
					return this.enfants_a_charge;
				}
				
			    public String profession;

				public String getProfession () {
					return this.profession;
				}
				
			    public String ville_region;

				public String getVille_region () {
					return this.ville_region;
				}
				
			    public Integer anciennete_mois;

				public Integer getAnciennete_mois () {
					return this.anciennete_mois;
				}
				
			    public Integer service_sms_banking;

				public Integer getService_sms_banking () {
					return this.service_sms_banking;
				}
				
			    public String acces_banque_en_ligne;

				public String getAcces_banque_en_ligne () {
					return this.acces_banque_en_ligne;
				}
				
			    public Integer alerte_securite_active;

				public Integer getAlerte_securite_active () {
					return this.alerte_securite_active;
				}
				
			    public Integer assurance_moyen_paiement;

				public Integer getAssurance_moyen_paiement () {
					return this.assurance_moyen_paiement;
				}
				
			    public Integer conseiller_dedie;

				public Integer getConseiller_dedie () {
					return this.conseiller_dedie;
				}
				
			    public Integer programme_fidelite;

				public Integer getProgramme_fidelite () {
					return this.programme_fidelite;
				}
				
			    public String type_convention;

				public String getType_convention () {
					return this.type_convention;
				}
				
			    public Integer e_releve_active;

				public Integer getE_releve_active () {
					return this.e_releve_active;
				}
				
			    public String methode_paiement_fav;

				public String getMethode_paiement_fav () {
					return this.methode_paiement_fav;
				}
				
			    public Double frais_bancaires_mensuels;

				public Double getFrais_bancaires_mensuels () {
					return this.frais_bancaires_mensuels;
				}
				
			    public Double total_frais_cumules;

				public Double getTotal_frais_cumules () {
					return this.total_frais_cumules;
				}
				
			    public Double revenu_mensuel;

				public Double getRevenu_mensuel () {
					return this.revenu_mensuel;
				}
				
			    public Long nb_produits_actifs;

				public Long getNb_produits_actifs () {
					return this.nb_produits_actifs;
				}
				
			    public Double score_risque_interne;

				public Double getScore_risque_interne () {
					return this.score_risque_interne;
				}
				
			    public Long churn;

				public Long getChurn () {
					return this.churn;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_client == null) ? 0 : this.id_client.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final after_tDBInput_1Struct other = (after_tDBInput_1Struct) obj;
		
						if (this.id_client == null) {
							if (other.id_client != null)
								return false;
						
						} else if (!this.id_client.equals(other.id_client))
						
							return false;
					

		return true;
    }

	public void copyDataTo(after_tDBInput_1Struct other) {

		other.id_client = this.id_client;
	            other.sexe = this.sexe;
	            other.date_naissance = this.date_naissance;
	            other.est_senior = this.est_senior;
	            other.situation_matrimoniale = this.situation_matrimoniale;
	            other.enfants_a_charge = this.enfants_a_charge;
	            other.profession = this.profession;
	            other.ville_region = this.ville_region;
	            other.anciennete_mois = this.anciennete_mois;
	            other.service_sms_banking = this.service_sms_banking;
	            other.acces_banque_en_ligne = this.acces_banque_en_ligne;
	            other.alerte_securite_active = this.alerte_securite_active;
	            other.assurance_moyen_paiement = this.assurance_moyen_paiement;
	            other.conseiller_dedie = this.conseiller_dedie;
	            other.programme_fidelite = this.programme_fidelite;
	            other.type_convention = this.type_convention;
	            other.e_releve_active = this.e_releve_active;
	            other.methode_paiement_fav = this.methode_paiement_fav;
	            other.frais_bancaires_mensuels = this.frais_bancaires_mensuels;
	            other.total_frais_cumules = this.total_frais_cumules;
	            other.revenu_mensuel = this.revenu_mensuel;
	            other.nb_produits_actifs = this.nb_produits_actifs;
	            other.score_risque_interne = this.score_risque_interne;
	            other.churn = this.churn;
	            
	}

	public void copyKeysDataTo(after_tDBInput_1Struct other) {

		other.id_client = this.id_client;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length) {
				if(length < 1024 && commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length == 0) {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[1024];
				} else {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length);
			strReturn = new String(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length) {
				if(length < 1024 && commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length == 0) {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[1024];
				} else {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length);
			strReturn = new String(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier) {

        	try {

        		int length = 0;
		
					this.id_client = readString(dis);
					
					this.sexe = readString(dis);
					
					this.date_naissance = readDate(dis);
					
						this.est_senior = readInteger(dis);
					
					this.situation_matrimoniale = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.enfants_a_charge = null;
           				} else {
           			    	this.enfants_a_charge = dis.readLong();
           				}
					
					this.profession = readString(dis);
					
					this.ville_region = readString(dis);
					
						this.anciennete_mois = readInteger(dis);
					
						this.service_sms_banking = readInteger(dis);
					
					this.acces_banque_en_ligne = readString(dis);
					
						this.alerte_securite_active = readInteger(dis);
					
						this.assurance_moyen_paiement = readInteger(dis);
					
						this.conseiller_dedie = readInteger(dis);
					
						this.programme_fidelite = readInteger(dis);
					
					this.type_convention = readString(dis);
					
						this.e_releve_active = readInteger(dis);
					
					this.methode_paiement_fav = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.frais_bancaires_mensuels = null;
           				} else {
           			    	this.frais_bancaires_mensuels = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_frais_cumules = null;
           				} else {
           			    	this.total_frais_cumules = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenu_mensuel = null;
           				} else {
           			    	this.revenu_mensuel = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.nb_produits_actifs = null;
           				} else {
           			    	this.nb_produits_actifs = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.score_risque_interne = null;
           				} else {
           			    	this.score_risque_interne = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.churn = null;
           				} else {
           			    	this.churn = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier) {

        	try {

        		int length = 0;
		
					this.id_client = readString(dis);
					
					this.sexe = readString(dis);
					
					this.date_naissance = readDate(dis);
					
						this.est_senior = readInteger(dis);
					
					this.situation_matrimoniale = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.enfants_a_charge = null;
           				} else {
           			    	this.enfants_a_charge = dis.readLong();
           				}
					
					this.profession = readString(dis);
					
					this.ville_region = readString(dis);
					
						this.anciennete_mois = readInteger(dis);
					
						this.service_sms_banking = readInteger(dis);
					
					this.acces_banque_en_ligne = readString(dis);
					
						this.alerte_securite_active = readInteger(dis);
					
						this.assurance_moyen_paiement = readInteger(dis);
					
						this.conseiller_dedie = readInteger(dis);
					
						this.programme_fidelite = readInteger(dis);
					
					this.type_convention = readString(dis);
					
						this.e_releve_active = readInteger(dis);
					
					this.methode_paiement_fav = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.frais_bancaires_mensuels = null;
           				} else {
           			    	this.frais_bancaires_mensuels = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_frais_cumules = null;
           				} else {
           			    	this.total_frais_cumules = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.revenu_mensuel = null;
           				} else {
           			    	this.revenu_mensuel = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.nb_produits_actifs = null;
           				} else {
           			    	this.nb_produits_actifs = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.score_risque_interne = null;
           				} else {
           			    	this.score_risque_interne = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.churn = null;
           				} else {
           			    	this.churn = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.id_client,dos);
					
					// String
				
						writeString(this.sexe,dos);
					
					// java.util.Date
				
						writeDate(this.date_naissance,dos);
					
					// Integer
				
						writeInteger(this.est_senior,dos);
					
					// String
				
						writeString(this.situation_matrimoniale,dos);
					
					// Long
				
						if(this.enfants_a_charge == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.enfants_a_charge);
		            	}
					
					// String
				
						writeString(this.profession,dos);
					
					// String
				
						writeString(this.ville_region,dos);
					
					// Integer
				
						writeInteger(this.anciennete_mois,dos);
					
					// Integer
				
						writeInteger(this.service_sms_banking,dos);
					
					// String
				
						writeString(this.acces_banque_en_ligne,dos);
					
					// Integer
				
						writeInteger(this.alerte_securite_active,dos);
					
					// Integer
				
						writeInteger(this.assurance_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.conseiller_dedie,dos);
					
					// Integer
				
						writeInteger(this.programme_fidelite,dos);
					
					// String
				
						writeString(this.type_convention,dos);
					
					// Integer
				
						writeInteger(this.e_releve_active,dos);
					
					// String
				
						writeString(this.methode_paiement_fav,dos);
					
					// Double
				
						if(this.frais_bancaires_mensuels == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.frais_bancaires_mensuels);
		            	}
					
					// Double
				
						if(this.total_frais_cumules == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_frais_cumules);
		            	}
					
					// Double
				
						if(this.revenu_mensuel == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.revenu_mensuel);
		            	}
					
					// Long
				
						if(this.nb_produits_actifs == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.nb_produits_actifs);
		            	}
					
					// Double
				
						if(this.score_risque_interne == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.score_risque_interne);
		            	}
					
					// Long
				
						if(this.churn == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.churn);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.id_client,dos);
					
					// String
				
						writeString(this.sexe,dos);
					
					// java.util.Date
				
						writeDate(this.date_naissance,dos);
					
					// Integer
				
						writeInteger(this.est_senior,dos);
					
					// String
				
						writeString(this.situation_matrimoniale,dos);
					
					// Long
				
						if(this.enfants_a_charge == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.enfants_a_charge);
		            	}
					
					// String
				
						writeString(this.profession,dos);
					
					// String
				
						writeString(this.ville_region,dos);
					
					// Integer
				
						writeInteger(this.anciennete_mois,dos);
					
					// Integer
				
						writeInteger(this.service_sms_banking,dos);
					
					// String
				
						writeString(this.acces_banque_en_ligne,dos);
					
					// Integer
				
						writeInteger(this.alerte_securite_active,dos);
					
					// Integer
				
						writeInteger(this.assurance_moyen_paiement,dos);
					
					// Integer
				
						writeInteger(this.conseiller_dedie,dos);
					
					// Integer
				
						writeInteger(this.programme_fidelite,dos);
					
					// String
				
						writeString(this.type_convention,dos);
					
					// Integer
				
						writeInteger(this.e_releve_active,dos);
					
					// String
				
						writeString(this.methode_paiement_fav,dos);
					
					// Double
				
						if(this.frais_bancaires_mensuels == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.frais_bancaires_mensuels);
		            	}
					
					// Double
				
						if(this.total_frais_cumules == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_frais_cumules);
		            	}
					
					// Double
				
						if(this.revenu_mensuel == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.revenu_mensuel);
		            	}
					
					// Long
				
						if(this.nb_produits_actifs == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.nb_produits_actifs);
		            	}
					
					// Double
				
						if(this.score_risque_interne == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.score_risque_interne);
		            	}
					
					// Long
				
						if(this.churn == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.churn);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_client="+id_client);
		sb.append(",sexe="+sexe);
		sb.append(",date_naissance="+String.valueOf(date_naissance));
		sb.append(",est_senior="+String.valueOf(est_senior));
		sb.append(",situation_matrimoniale="+situation_matrimoniale);
		sb.append(",enfants_a_charge="+String.valueOf(enfants_a_charge));
		sb.append(",profession="+profession);
		sb.append(",ville_region="+ville_region);
		sb.append(",anciennete_mois="+String.valueOf(anciennete_mois));
		sb.append(",service_sms_banking="+String.valueOf(service_sms_banking));
		sb.append(",acces_banque_en_ligne="+acces_banque_en_ligne);
		sb.append(",alerte_securite_active="+String.valueOf(alerte_securite_active));
		sb.append(",assurance_moyen_paiement="+String.valueOf(assurance_moyen_paiement));
		sb.append(",conseiller_dedie="+String.valueOf(conseiller_dedie));
		sb.append(",programme_fidelite="+String.valueOf(programme_fidelite));
		sb.append(",type_convention="+type_convention);
		sb.append(",e_releve_active="+String.valueOf(e_releve_active));
		sb.append(",methode_paiement_fav="+methode_paiement_fav);
		sb.append(",frais_bancaires_mensuels="+String.valueOf(frais_bancaires_mensuels));
		sb.append(",total_frais_cumules="+String.valueOf(total_frais_cumules));
		sb.append(",revenu_mensuel="+String.valueOf(revenu_mensuel));
		sb.append(",nb_produits_actifs="+String.valueOf(nb_produits_actifs));
		sb.append(",score_risque_interne="+String.valueOf(score_risque_interne));
		sb.append(",churn="+String.valueOf(churn));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(after_tDBInput_1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_client, other.id_client);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;


		tDBInput_2Process(globalMap);

		row1Struct row1 = new row1Struct();
dimStruct dim = new dimStruct();





	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"dim");
					}
				
		int tos_count_tDBOutput_1 = 0;
		





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = context.schema;
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("DIM_FINANCIER");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("DIM_FINANCIER");
}

        int updateKeyCount_tDBOutput_1 = 1;
        if(updateKeyCount_tDBOutput_1 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_1 == 7 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }

int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+context.host+":"+context.port+"/"+context.database + "?" + context.params;
    dbUser_tDBOutput_1 = context.username;

	final String decryptedPassword_tDBOutput_1 = context.password; 

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;



int count_tDBOutput_1=0;
                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_1 = conn_tDBOutput_1.getMetaData();
                                boolean whetherExist_tDBOutput_1 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_1 = dbMetaData_tDBOutput_1.getTables(null, null, null, new String[]{"TABLE"})) {
                                    String defaultSchema_tDBOutput_1 = "public";
                                    if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
                                        try(java.sql.Statement stmtSchema_tDBOutput_1 = conn_tDBOutput_1.createStatement();
                                            java.sql.ResultSet rsSchema_tDBOutput_1 = stmtSchema_tDBOutput_1.executeQuery("select current_schema() ")) {
                                            while(rsSchema_tDBOutput_1.next()){
                                                defaultSchema_tDBOutput_1 = rsSchema_tDBOutput_1.getString("current_schema");
                                            }
                                        }
                                    }
                                    while(rsTable_tDBOutput_1.next()) {
                                        String table_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_NAME");
                                        String schema_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_SCHEM");
                                        if(table_tDBOutput_1.equals(("DIM_FINANCIER"))
                                            && (schema_tDBOutput_1.equals(dbschema_tDBOutput_1) || ((dbschema_tDBOutput_1 ==null || dbschema_tDBOutput_1.trim().length() ==0) && defaultSchema_tDBOutput_1.equals(schema_tDBOutput_1)))) {
                                            whetherExist_tDBOutput_1 = true;
                                            break;
                                        }
                                    }
                                }
                                if(!whetherExist_tDBOutput_1) {
                                    try (java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                                        stmtCreate_tDBOutput_1.execute("CREATE TABLE \"" + tableName_tDBOutput_1 + "\"(\"id_financier_sk\" SERIAL  not null ,\"id_client\" VARCHAR(10)   not null ,\"id_type_convention_sk\" SERIAL  not null ,\"methode_paiement_fav\" VARCHAR(16)  ,\"frais_bancaires_mensuels\" FLOAT8 ,\"total_frais_cumules\" FLOAT8 ,\"revenu_mensuel\" FLOAT8 ,primary key(\"id_client\"))");
                                    }
                                }
	    String update_tDBOutput_1 = "UPDATE \"" + tableName_tDBOutput_1 + "\" SET \"id_client\" = ?,\"id_type_convention_sk\" = ?,\"methode_paiement_fav\" = ?,\"frais_bancaires_mensuels\" = ?,\"total_frais_cumules\" = ?,\"revenu_mensuel\" = ? WHERE \"id_client\" = ?";
	    java.sql.PreparedStatement pstmtUpdate_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(update_tDBOutput_1);
	    resourceMap.put("pstmtUpdate_tDBOutput_1", pstmtUpdate_tDBOutput_1);
	    String insert_tDBOutput_1 = "INSERT INTO \"" + tableName_tDBOutput_1 + "\" (\"id_client\",\"id_type_convention_sk\",\"methode_paiement_fav\",\"frais_bancaires_mensuels\",\"total_frais_cumules\",\"revenu_mensuel\") VALUES (?,?,?,?,?,?)";
	    java.sql.PreparedStatement pstmtInsert_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmtInsert_tDBOutput_1", pstmtInsert_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) 
					globalMap.get( "tHash_Lookup_row2" ))
					;					
					
	

row2Struct row2HashKey = new row2Struct();
row2Struct row2Default = new row2Struct();
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
dimStruct dim_tmp = new dimStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";

	
		int tos_count_tDBInput_1 = 0;
		
	
    
	
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = context.username;
				
				
	final String decryptedPassword_tDBInput_1 = context.password; 
				
				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;
				
				String url_tDBInput_1 = "jdbc:postgresql://" + context.host + ":" + context.port + "/" + context.database + "?" + context.params;
				
				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1,dbUser_tDBInput_1,dbPwd_tDBInput_1);
		        
				conn_tDBInput_1.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT \n  \""+context.schema_staging+"\".\"stg_clients\".\"id_client\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"sexe\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"date_naissance\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"est_senior\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"situation_matrimoniale\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"enfants_a_charge\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"profession\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"ville_region\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"anciennete_mois\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"service_sms_banking\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"acces_banque_en_ligne\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"alerte_securite_active\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"assurance_moyen_paiement\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"conseiller_dedie\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"programme_fidelite\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"type_convention\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"e_releve_active\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"methode_paiement_fav\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"frais_bancaires_mensuels\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"total_frais_cumules\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"revenu_mensuel\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"nb_produits_actifs\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"score_risque_interne\", \n  \""+context.schema_staging+"\".\"stg_clients\".\"churn\"\nFROM \""+context.schema_staging+"\".\"stg_clients\"";
		    

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.id_client = null;
							} else {
	                         		
        	row1.id_client = routines.system.JDBCUtil.getString(rs_tDBInput_1, 1, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.sexe = null;
							} else {
	                         		
        	row1.sexe = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.date_naissance = null;
							} else {
										
			row1.date_naissance = routines.system.JDBCUtil.getDate(rs_tDBInput_1, 3);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.est_senior = null;
							} else {
		                          
            row1.est_senior = rs_tDBInput_1.getInt(4);
            if(rs_tDBInput_1.wasNull()){
                    row1.est_senior = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.situation_matrimoniale = null;
							} else {
	                         		
        	row1.situation_matrimoniale = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.enfants_a_charge = null;
							} else {
		                          
            row1.enfants_a_charge = rs_tDBInput_1.getLong(6);
            if(rs_tDBInput_1.wasNull()){
                    row1.enfants_a_charge = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.profession = null;
							} else {
	                         		
        	row1.profession = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.ville_region = null;
							} else {
	                         		
        	row1.ville_region = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row1.anciennete_mois = null;
							} else {
		                          
            row1.anciennete_mois = rs_tDBInput_1.getInt(9);
            if(rs_tDBInput_1.wasNull()){
                    row1.anciennete_mois = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row1.service_sms_banking = null;
							} else {
		                          
            row1.service_sms_banking = rs_tDBInput_1.getInt(10);
            if(rs_tDBInput_1.wasNull()){
                    row1.service_sms_banking = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row1.acces_banque_en_ligne = null;
							} else {
	                         		
        	row1.acces_banque_en_ligne = routines.system.JDBCUtil.getString(rs_tDBInput_1, 11, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row1.alerte_securite_active = null;
							} else {
		                          
            row1.alerte_securite_active = rs_tDBInput_1.getInt(12);
            if(rs_tDBInput_1.wasNull()){
                    row1.alerte_securite_active = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row1.assurance_moyen_paiement = null;
							} else {
		                          
            row1.assurance_moyen_paiement = rs_tDBInput_1.getInt(13);
            if(rs_tDBInput_1.wasNull()){
                    row1.assurance_moyen_paiement = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row1.conseiller_dedie = null;
							} else {
		                          
            row1.conseiller_dedie = rs_tDBInput_1.getInt(14);
            if(rs_tDBInput_1.wasNull()){
                    row1.conseiller_dedie = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row1.programme_fidelite = null;
							} else {
		                          
            row1.programme_fidelite = rs_tDBInput_1.getInt(15);
            if(rs_tDBInput_1.wasNull()){
                    row1.programme_fidelite = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row1.type_convention = null;
							} else {
	                         		
        	row1.type_convention = routines.system.JDBCUtil.getString(rs_tDBInput_1, 16, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 17) {
								row1.e_releve_active = null;
							} else {
		                          
            row1.e_releve_active = rs_tDBInput_1.getInt(17);
            if(rs_tDBInput_1.wasNull()){
                    row1.e_releve_active = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 18) {
								row1.methode_paiement_fav = null;
							} else {
	                         		
        	row1.methode_paiement_fav = routines.system.JDBCUtil.getString(rs_tDBInput_1, 18, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 19) {
								row1.frais_bancaires_mensuels = null;
							} else {
	                         		
            row1.frais_bancaires_mensuels = rs_tDBInput_1.getDouble(19);
            if(rs_tDBInput_1.wasNull()){
                    row1.frais_bancaires_mensuels = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 20) {
								row1.total_frais_cumules = null;
							} else {
	                         		
            row1.total_frais_cumules = rs_tDBInput_1.getDouble(20);
            if(rs_tDBInput_1.wasNull()){
                    row1.total_frais_cumules = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 21) {
								row1.revenu_mensuel = null;
							} else {
	                         		
            row1.revenu_mensuel = rs_tDBInput_1.getDouble(21);
            if(rs_tDBInput_1.wasNull()){
                    row1.revenu_mensuel = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 22) {
								row1.nb_produits_actifs = null;
							} else {
		                          
            row1.nb_produits_actifs = rs_tDBInput_1.getLong(22);
            if(rs_tDBInput_1.wasNull()){
                    row1.nb_produits_actifs = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 23) {
								row1.score_risque_interne = null;
							} else {
	                         		
            row1.score_risque_interne = rs_tDBInput_1.getDouble(23);
            if(rs_tDBInput_1.wasNull()){
                    row1.score_risque_interne = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 24) {
								row1.churn = null;
							} else {
		                          
            row1.churn = rs_tDBInput_1.getLong(24);
            if(rs_tDBInput_1.wasNull()){
                    row1.churn = null;
            }
		                    }
					


 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		

				///////////////////////////////////////////////
				// Starting Lookup Table "row2" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLooprow2 = false;
       		  	    	
       		  	    	
 							row2Struct row2ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								
								hasCasePrimitiveKeyWithNull_tMap_1 = false;
								
                        		    		    row2HashKey.type_convention = row1.type_convention ;
                        		    		

								
		                        	row2HashKey.hashCodeDirty = true;
                        		
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_row2.lookup( row2HashKey );

	  							

	  							

 								
		  				
	  								
						
									
  									  		
 								



							} // G_TM_M_020
			           		  	  
							
				           		if(tHash_Lookup_row2 != null && tHash_Lookup_row2.getCount(row2HashKey) > 1) { // G 071
			  							
			  						
									 		
									//System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row2' and it contains more one result from keys :  row2.type_convention = '" + row2HashKey.type_convention + "'");
								} // G 071
							

							row2Struct row2 = null;
                    		  	 
							   
                    		  	 
	       		  	    	row2Struct fromLookup_row2 = null;
							row2 = row2Default;
										 
							
								 
							
							
								if (tHash_Lookup_row2 !=null && tHash_Lookup_row2.hasNext()) { // G 099
								
							
								
								fromLookup_row2 = tHash_Lookup_row2.next();

							
							
								} // G 099
							
							

							if(fromLookup_row2 != null) {
								row2 = fromLookup_row2;
							}
							
							
							
			  							
								
	                    		  	
		                    
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

dim = null;


// # Output table : 'dim'
dim_tmp.id_financier_sk = 0;
dim_tmp.id_client = row1.id_client ;
dim_tmp.id_type_convention_sk = row2.id_type_convention_sk ;
dim_tmp.methode_paiement_fav = row1.methode_paiement_fav ;
dim_tmp.frais_bancaires_mensuels = row1.frais_bancaires_mensuels ;
dim_tmp.total_frais_cumules = row1.total_frais_cumules ;
dim_tmp.revenu_mensuel = row1.revenu_mensuel ;
dim = dim_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "dim"
if(dim != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"dim"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
            int updateFlag_tDBOutput_1=0;
                    if(dim.id_client == null) {
pstmtUpdate_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(1, dim.id_client);
}

                    pstmtUpdate_tDBOutput_1.setInt(2, dim.id_type_convention_sk);

                    if(dim.methode_paiement_fav == null) {
pstmtUpdate_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(3, dim.methode_paiement_fav);
}

                    if(dim.frais_bancaires_mensuels == null) {
pstmtUpdate_tDBOutput_1.setNull(4, java.sql.Types.DOUBLE);
} else {pstmtUpdate_tDBOutput_1.setDouble(4, dim.frais_bancaires_mensuels);
}

                    if(dim.total_frais_cumules == null) {
pstmtUpdate_tDBOutput_1.setNull(5, java.sql.Types.DOUBLE);
} else {pstmtUpdate_tDBOutput_1.setDouble(5, dim.total_frais_cumules);
}

                    if(dim.revenu_mensuel == null) {
pstmtUpdate_tDBOutput_1.setNull(6, java.sql.Types.DOUBLE);
} else {pstmtUpdate_tDBOutput_1.setDouble(6, dim.revenu_mensuel);
}


                    if(dim.id_client == null) {
pstmtUpdate_tDBOutput_1.setNull(7 + count_tDBOutput_1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(7 + count_tDBOutput_1, dim.id_client);
}


            try {
				
                updateFlag_tDBOutput_1=pstmtUpdate_tDBOutput_1.executeUpdate();
                updatedCount_tDBOutput_1 = updatedCount_tDBOutput_1+updateFlag_tDBOutput_1;
                rowsToCommitCount_tDBOutput_1 += updateFlag_tDBOutput_1;
				
            if(updateFlag_tDBOutput_1 == 0) {
            	
                        if(dim.id_client == null) {
pstmtInsert_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(1, dim.id_client);
}

                        pstmtInsert_tDBOutput_1.setInt(2, dim.id_type_convention_sk);

                        if(dim.methode_paiement_fav == null) {
pstmtInsert_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(3, dim.methode_paiement_fav);
}

                        if(dim.frais_bancaires_mensuels == null) {
pstmtInsert_tDBOutput_1.setNull(4, java.sql.Types.DOUBLE);
} else {pstmtInsert_tDBOutput_1.setDouble(4, dim.frais_bancaires_mensuels);
}

                        if(dim.total_frais_cumules == null) {
pstmtInsert_tDBOutput_1.setNull(5, java.sql.Types.DOUBLE);
} else {pstmtInsert_tDBOutput_1.setDouble(5, dim.total_frais_cumules);
}

                        if(dim.revenu_mensuel == null) {
pstmtInsert_tDBOutput_1.setNull(6, java.sql.Types.DOUBLE);
} else {pstmtInsert_tDBOutput_1.setDouble(6, dim.revenu_mensuel);
}

					
                    int processedCount_tDBOutput_1 = pstmtInsert_tDBOutput_1.executeUpdate();
                    insertedCount_tDBOutput_1 += processedCount_tDBOutput_1;
                    rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                    nb_line_tDBOutput_1++;
					
    	            }else{
    					nb_line_tDBOutput_1++;
    					
     					
    				}
                } catch(java.lang.Exception e) {
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e.getMessage());
					
                    whetherReject_tDBOutput_1 = true;
                        nb_line_tDBOutput_1++;
                            System.err.print(e.getMessage());
                }
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "dim"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
	if(conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {
		
			conn_tDBInput_1.commit();
			
		
			conn_tDBInput_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
 

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_row2 != null) {
						tHash_Lookup_row2.endGet();
					}
					globalMap.remove( "tHash_Lookup_row2" );

					
					
				
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



        if(pstmtUpdate_tDBOutput_1 != null){
            pstmtUpdate_tDBOutput_1.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_1");
        }
        if(pstmtInsert_tDBOutput_1 != null){
            pstmtInsert_tDBOutput_1.close();
            resourceMap.remove("pstmtInsert_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
    	conn_tDBOutput_1 .close();
    	
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	


				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"dim");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
					     			//free memory for "tMap_1"
					     			globalMap.remove("tHash_Lookup_row2"); 
				     			
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";

	

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_1 = null;
                if ((pstmtUpdateToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_1")) != null) {
                    pstmtUpdateToClose_tDBOutput_1.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_1 = null;
                if ((pstmtInsertToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_1")) != null) {
                    pstmtInsertToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                    ctn_tDBOutput_1.close();
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableComparableLookupRow<row2Struct> {
    final static byte[] commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[0];
    static byte[] commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id_type_convention_sk;

				public int getId_type_convention_sk () {
					return this.id_type_convention_sk;
				}
				
			    public String type_convention;

				public String getType_convention () {
					return this.type_convention;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.type_convention == null) ? 0 : this.type_convention.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.type_convention == null) {
							if (other.type_convention != null)
								return false;
						
						} else if (!this.type_convention.equals(other.type_convention))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.id_type_convention_sk = this.id_type_convention_sk;
	            other.type_convention = this.type_convention;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.type_convention = this.type_convention;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length) {
				if(length < 1024 && commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length == 0) {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[1024];
				} else {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length);
			strReturn = new String(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length) {
				if(length < 1024 && commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier.length == 0) {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[1024];
				} else {
   					commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length);
			strReturn = new String(commonByteArray_DWH_ATTEJARIBANK_J_Load_Dim_Finanier, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readKeysData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier) {

        	try {

        		int length = 0;
		
					this.type_convention = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_DWH_ATTEJARIBANK_J_Load_Dim_Finanier) {

        	try {

        		int length = 0;
		
					this.type_convention = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeKeysData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.type_convention,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.type_convention,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }



    /**
     * Fill Values data by reading ObjectInputStream.
     */
    public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
        try {

			int length = 0;
		
			            this.id_type_convention_sk = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }
    
    public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
        try {
			int length = 0;
		
			            this.id_type_convention_sk = objectIn.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

    }

    /**
     * Return a byte array which represents Values data.
     */
    public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
        try {

		
		            	dos.writeInt(this.id_type_convention_sk);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}

    }
    
    public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut){
                try {

		
					objectOut.writeInt(this.id_type_convention_sk);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        	}
    }


    
    public boolean supportMarshaller(){
        return true;
    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_type_convention_sk="+String.valueOf(id_type_convention_sk));
		sb.append(",type_convention="+type_convention);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.type_convention, other.type_convention);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tAdvancedHash_row2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_row2", false);
		start_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_row2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tAdvancedHash_row2 = 0;
		

			   		// connection name:row2
			   		// source node:tDBInput_2 - inputs:(after_tDBInput_1) outputs:(row2,row2) | target node:tAdvancedHash_row2 - inputs:(row2) outputs:()
			   		// linked node: tMap_1 - inputs:(row1,row2) outputs:(dim)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row2 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<row2Struct>getLookup(matchingModeEnum_row2);
	   						   
		   	   	   globalMap.put("tHash_Lookup_row2", tHash_Lookup_row2);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_row2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";

	
		int tos_count_tDBInput_2 = 0;
		
	
    
	
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				String driverClass_tDBInput_2 = "org.postgresql.Driver";
			    java.lang.Class jdbcclazz_tDBInput_2 = java.lang.Class.forName(driverClass_tDBInput_2);
				String dbUser_tDBInput_2 = context.username;
				
				
	final String decryptedPassword_tDBInput_2 = context.password; 
				
				String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;
				
				String url_tDBInput_2 = "jdbc:postgresql://" + context.host + ":" + context.port + "/" + context.database + "?" + context.params;
				
				conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2,dbUser_tDBInput_2,dbPwd_tDBInput_2);
		        
				conn_tDBInput_2.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT \n  \""+context.schema+"\".\"DIM_TYPE_CONVENTION\".\"id_type_convention_sk\", \n  \""+context.schema+"\".\"DIM_TYPE_CONVENTION\".\"type_convention\"\nFROM \""+context.schema+"\".\"DIM_TYPE_CONVENTION\"";
		    

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.id_type_convention_sk = 0;
							} else {
		                          
            row2.id_type_convention_sk = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.type_convention = null;
							} else {
	                         		
        	row2.type_convention = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
					


 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAdvancedHash_row2 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					


			   
			   

					row2Struct row2_HashRow = new row2Struct();
		   	   	   
				
				row2_HashRow.id_type_convention_sk = row2.id_type_convention_sk;
				
				row2_HashRow.type_convention = row2.type_convention;
				
			tHash_Lookup_row2.put(row2_HashRow);
			
            




 


	tos_count_tAdvancedHash_row2++;

/**
 * [tAdvancedHash_row2 main ] stop
 */
	
	/**
	 * [tAdvancedHash_row2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";

	

 



/**
 * [tAdvancedHash_row2 process_data_begin ] stop
 */
	
	/**
	 * [tAdvancedHash_row2 process_data_end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";

	

 



/**
 * [tAdvancedHash_row2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
	if(conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {
		
			conn_tDBInput_2.commit();
			
		
			conn_tDBInput_2.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	}
	
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
 

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tAdvancedHash_row2 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";

	

tHash_Lookup_row2.endPut();

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tAdvancedHash_row2", true);
end_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());




/**
 * [tAdvancedHash_row2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";

	

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tAdvancedHash_row2 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_row2";

	

 



/**
 * [tAdvancedHash_row2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Docker";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final J_Load_Dim_Finanier J_Load_Dim_FinanierClass = new J_Load_Dim_Finanier();

        int exitCode = J_Load_Dim_FinanierClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = J_Load_Dim_Finanier.class.getClassLoader().getResourceAsStream("dwh_attejaribank/j_load_dim_finanier_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = J_Load_Dim_Finanier.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("host", "id_String");
                        if(context.getStringValue("host") == null) {
                            context.host = null;
                        } else {
                            context.host=(String) context.getProperty("host");
                        }
                        context.setContextType("port", "id_BigDecimal");
                        if(context.getStringValue("port") == null) {
                            context.port = null;
                        } else {
                            try{
                                context.port=routines.system.ParserUtils.parseTo_BigDecimal (context.getProperty("port"));
                            } catch(NumberFormatException e){
                                System.err.println(String.format("Null value will be used for context parameter %s: %s", "port", e.getMessage()));
                                context.port=null;
                            }
                        }
                        context.setContextType("schema", "id_String");
                        if(context.getStringValue("schema") == null) {
                            context.schema = null;
                        } else {
                            context.schema=(String) context.getProperty("schema");
                        }
                        context.setContextType("database", "id_String");
                        if(context.getStringValue("database") == null) {
                            context.database = null;
                        } else {
                            context.database=(String) context.getProperty("database");
                        }
                        context.setContextType("password", "id_String");
                        if(context.getStringValue("password") == null) {
                            context.password = null;
                        } else {
                            context.password=(String) context.getProperty("password");
                        }
                        context.setContextType("params", "id_String");
                        if(context.getStringValue("params") == null) {
                            context.params = null;
                        } else {
                            context.params=(String) context.getProperty("params");
                        }
                        context.setContextType("username", "id_String");
                        if(context.getStringValue("username") == null) {
                            context.username = null;
                        } else {
                            context.username=(String) context.getProperty("username");
                        }
                        context.setContextType("schema_staging", "id_String");
                        if(context.getStringValue("schema_staging") == null) {
                            context.schema_staging = null;
                        } else {
                            context.schema_staging=(String) context.getProperty("schema_staging");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("host")) {
                context.host = (String) parentContextMap.get("host");
            }if (parentContextMap.containsKey("port")) {
                context.port = (BigDecimal) parentContextMap.get("port");
            }if (parentContextMap.containsKey("schema")) {
                context.schema = (String) parentContextMap.get("schema");
            }if (parentContextMap.containsKey("database")) {
                context.database = (String) parentContextMap.get("database");
            }if (parentContextMap.containsKey("password")) {
                context.password = (String) parentContextMap.get("password");
            }if (parentContextMap.containsKey("params")) {
                context.params = (String) parentContextMap.get("params");
            }if (parentContextMap.containsKey("username")) {
                context.username = (String) parentContextMap.get("username");
            }if (parentContextMap.containsKey("schema_staging")) {
                context.schema_staging = (String) parentContextMap.get("schema_staging");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob





this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : J_Load_Dim_Finanier");
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     141772 characters generated by Talend Open Studio for Data Integration 
 *     on the 16 avril 2026 à 15:48:53 WAT
 ************************************************************************************************/